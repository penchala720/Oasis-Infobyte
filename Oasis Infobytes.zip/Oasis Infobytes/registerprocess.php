<?php
 
include("database.php");

$name = $_POST['usename'];
$mail = $_POST['uemail'];
$pass = $_POST['ucpas'];
$mblno = $_POST['umbn'];
$address = $_POST['uadres'];

// query to fetch for existing mail
$response = mysqli_query($conn, "SELECT * FROM userdetail where email = '$mail' ");

// Validate username
if (!preg_match("/^[a-zA-Z0-9_\- ]{3,20}$/", $name)) {
    echo "<script> alert('Invalid username. Username should be between 3 and 20 characters and can only contain letters, numbers, spaces, hyphens, and underscores.');
          location.href = 'index.php';
          </script>";
    exit();
}

// Validate phone number
if (!preg_match("/^[6-9]\d{9}$/", $mblno)) {
    echo "<script> alert('Invalid phone number. Please enter a 10-digit phone number starting with 6, 7, 8, or 9.');
          location.href = 'index.php';
          </script>";
    exit();
}

// Validate email address
if (!filter_var($mail, FILTER_VALIDATE_EMAIL)) {
    echo "<script> alert('Invalid email address.');
          location.href = 'index.php';
          </script>";
    exit();
}
// if user exists
if(mysqli_num_rows($response)>0)
{
    echo "<script> alert('E-mail already exitsted!..Try new');
          location.href = 'index.php';
          </script>";

	exit();
}


//if not insert into the DB
$sql_query = "INSERT into userdetail(name,email, password, phno, address) values('$name', '$mail', '$pass', '$mblno', '$address')";
mysqli_query($conn, $sql_query);
$conn->close();

echo "<script> alert('Succesfully Registered!..'); </script>";

header("Location: index.php");


// else(isset($_POST['save']))
// {
//     $file = rand(1000,100000)."-".$_FILES['file']['name'];
//     $file_loc = $_FILES['file']['tmp_name'];
//     $folder="upload/";
//     $new_file_name = strtolower($file);
//     $final_file=str_replace(' ','-',$new_file_name);
//     if(move_uploaded_file($file_loc,$folder.$final_file))
//     {
//         $query="INSERT INTO register(First_Name, Last_Name, Email, Password, File ) VALUES ('$first_name', '$last_name', '$email', 'md5($pass)', '$final_file')";
//         $sql=mysqli_query($conn,$query)or die("Could Not Perform the Query");
//         header ("Location: index.php?status=success");
//     }
//     else 
//     {
// 		echo "Error.Please try again";
// 	}

?>