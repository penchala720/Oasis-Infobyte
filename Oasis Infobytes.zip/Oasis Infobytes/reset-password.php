<?php
// Connect to the database
include("database.php");

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  
  // Check if a token was provided in the POST data
  if (empty($_POST['token'])) {
    die('Invalid request');
  }
  
  // Collect the token from the POST data
  $token = $_POST['token'];
  
  // Check if the token exists in the database
  $query = "SELECT * FROM password_resets WHERE token = '$token'";
  $result = mysqli_query($conn, $query);

  if (mysqli_num_rows($result) == 0) {
    die('Invalid token');
  }

  // Collect the email address associated with the token
  $row = mysqli_fetch_assoc($result);
  $email = $row['email'];

  // Collect the new password from the form
  $new_password = $_POST['new_password'];

  // Validate the new password
  if (strlen($new_password) < 8) {
    $error = 'Password must be at least 8 characters long';
  } else {

    // Hash the new password
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

    // Update the user's password in the database
    $query = "UPDATE userdetail SET password = '$hashed_password' WHERE email = '$email'";
    mysqli_query($conn, $query);

    // Delete the password reset token from the database
    $query = "DELETE FROM password_resets WHERE token = '$token'";
    mysqli_query($conn, $query);

    // Display a success message
    $success = 'Your password has been reset';
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Reset Password</title>
</head>
<body>
  <?php if (isset($error)): ?>
    <p>Error: <?php echo $error ?></p>
  <?php endif ?>

  <?php if (isset($success)): ?>
    <p><?php echo $success ?></p>
  <?php else: ?>
    <form method="post">
      <input type="hidden" name="token" value="<?php echo $_POST['token'] ?>">
      <label>New password:</label>
      <input type="password" name="new_password" required>
      <button type="submit">Reset Password</button>
    </form>
  <?php endif ?>
</body>
</html>
