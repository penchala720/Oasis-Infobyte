<?php
include("database.php");
$uemaill=$_POST['usema'];
$pasw=$_POST['passw'];
//setting up the cookie to retrive it in vamsi.php
setcookie("varus_name", $uemaill, time() + 3600); 



$sql="SELECT * from userdetail WHERE email='$uemaill'and password='$pasw'";
$response = mysqli_query($conn, $sql);
if(mysqli_num_rows($response)>0)
{
    header("Location: vamsi.php");
}
else
{
    echo "<script> alert('username and password are incorrect or signup');
    location.href = 'index.php';
    </script>";
}
$conn->close();

// if(isset($_POST['save']))
// {
//     extract($_POST);
//     include 'database.php';
//     $sql=mysqli_query($conn,"SELECT * FROM register where Email='$email' and Password='md5($pass)'");
//     $row  = mysqli_fetch_array($sql);
//     if(is_array($row))
//     {
//         $_SESSION["ID"] = $row['ID'];
//         $_SESSION["Email"]=$row['Email'];
//         $_SESSION["First_Name"]=$row['First_Name'];
//         $_SESSION["Last_Name"]=$row['Last_Name']; 
//         header("Location: vamsi.html"); 
//     }
//     else
//     {
//         echo "Invalid Email ID/Password";
//     }
// }
?>