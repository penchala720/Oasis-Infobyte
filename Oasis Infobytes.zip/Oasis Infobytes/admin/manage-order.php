<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders</title>
</head>
<body>
<?php include('partials/menu.php'); ?>
<div class="main-content">
    <div class="wrapper">
        <h1>Manage Order</h1>

        <br /><br /><br />

        <?php 
            if(isset($_SESSION['update']))
            {
                echo $_SESSION['update'];
                unset($_SESSION['update']);
            }
        ?>
        <br><br>

        <table>
            <tr>
                <th>Email</th>
                <th>Food</th>
                <th>Price</th>
                <th>Date</th>
                <th>Status</th>
                <th>Customer Name</th>
                <th>Contact</th>
                <th>Address</th>
                <th>Actions</th>
                <th>Clicktoupdate</th>
            </tr>

                       <?php 
                // Get all the orders from the database
                $sql = "SELECT * FROM orders ORDER BY date DESC"; // Display the Latest Order at First
                // Execute Query
                $res = mysqli_query($conn, $sql);
                // Count the Rows
                $count = mysqli_num_rows($res);

                $sn = 1; // Create a Serial Number and set its initial value as 1

                if($count>0)
                {
                    // Order Available
                    while($row=mysqli_fetch_assoc($res))
                    {
                        // Get all the order details
                        $customer_email = $row['usere'];
                        $food = $row['itemname'];
                        $price = $row['itemprice'];
                        $order_date = $row['date'];
                        $status = $row['orderstatus'];
                        $customer_name = $row['customername'];
                        $customer_contact = $row['customercontact'];
                        $customer_address = $row['customeraddress'];
                        
                        ?>

                        <tr>
                            <td><?php echo $customer_email; ?>. </td>
                            <td><?php echo $food; ?></td>
                            <td><?php echo $price; ?></td>
                            <td><?php echo $order_date; ?></td>

                            <td>
                                <?php 
                                    // Ordered, On Delivery, Delivered, Cancelled
                                    if($status=="Ordered" OR $status=="ordered")
                                    {
                                        echo "<label>$status</label>";
                                    }
                                    elseif($status=="On Delivery")
                                    {
                                        echo "<label style='color: orange;'>$status</label>";
                                    }
                                    elseif($status=="Delivered")
                                    {
                                        echo "<label style='color: green;'>$status</label>";
                                    }
                                    elseif($status=="Cancelled")
                                    {
                                        echo "<label style='color: red;'>$status</label>";
                                    }
                                ?>
                            </td>

                            <td><?php echo $customer_name; ?></td>
                            <td><?php echo $customer_contact; ?></td>
                            <td><?php echo $customer_address; ?></td>
                            <form action="update-order.php" method="POST">
                                <td>
                                    <select name="statusuu">
                                        <option <?php if($status=="Ordered"){echo "selected";} ?> value="Ordered">Ordered</option>
                                        <option <?php if($status=="On Delivery"){echo "selected";} ?> value="On Delivery">On Delivery</option>
                                        <option <?php if($status=="Delivered"){echo "selected";} ?> value="Delivered">Delivered</option>
                                        <option <?php if($status=="Cancelled"){echo "selected";} ?> value="Cancelled">Cancelled</option>
                                    </select>
                                </td>
                                <td><input type="submit" name="submit" value="UPDATE" class="btn-primary"></td>
                                <input type="hidden" name="useremailll" value="<?php echo $customer_email; ?>">
                                <input type="hidden" name="userfooddd" value="<?php echo $food; ?>">
                                <input type="hidden" name="userdateee" value="<?php echo $order_date; ?>">
                            </form>
                        </tr>
                                               
                        <?php
                    } // closing brace for the while loop
                }
                else
                {
                    // Order not Available
                    echo "<tr><td colspan='12' class='error'>Orders not Available</td></tr>";
                }
            ?>

        </table>
    </div>
</div>
<?php include('partials/footer.php'); ?>
</body>
</html>
