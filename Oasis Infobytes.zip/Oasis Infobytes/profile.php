<!DOCTYPE html>
<html>
<head>
    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #ff5d4c;
            margin: 0;
            padding: 20px;
        }

        .container {
            width: 80%;
            max-width: 100%;
            min-height: 70%;
            max-height: 80%;
            background-color: #fff;
            border-radius: 5px;
            padding: 20px;
            margin: 0 auto;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #333;
            text-align: center;
            font-size: 28px;
        }

        form {
            margin-top: 20px;
        }

        input[type="text"],
        input[type="email"],
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: #fff;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        .success-message {
            color: #4CAF50;
            margin-top: 10px;
        }

        .error-message {
            color: #f44336;
            margin-top: 10px;
        }

        /* Responsive adjustments */
        @media (max-width: 576px) {
            h1 {
                font-size: 24px;
            }

            input[type="text"],
            input[type="email"],
            input[type="submit"] {
                width: 100%;
                font-size: 20px;
            }
        }

        @media (max-width: 768px) {
            h1 {
                font-size: 26px;
            }
            p {
                font-size: 26px;
            }
            input{
                font-size: 26px;
            }
            
        }

        @media (max-width: 992px) {
            h1 {
                font-size: 28px;
            }
            p {
                font-size: 26px;
            }
            input{
                font-size: 26px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Profile</h1>
        <?php
            // include connection to database
            include("database.php");

            //retrieving the cookie here - created in loginprocess.php
            $userId = $_COOKIE['varus_name']; 

            // Function to fetch user details by ID
            function getUserDetails($conn, $user)
            {
                $query = "SELECT * FROM userdetail WHERE email = '$user'";
                $response = mysqli_query($conn, $query);
                if(mysqli_num_rows($response) > 0)
                {
                    return $response->fetch_assoc();
                }
                return false;
            }

            // Function to update user details
            function updateUserDetails($conn, $userId, $name, $address, $phno)
            {
                $query = "UPDATE userdetail SET name = '$name', address = '$address', phno = '$phno' WHERE email = '$userId'";
                return $conn->query($query);
            }

            // Get user details
            $userDetails = getUserDetails($conn, $userId);

            if ($userDetails) {
                // Display user details
                echo "<p>Name: " . $userDetails['name'] . "</p>";
                echo "<p>Address: " . $userDetails['address'] . "</p>";
                echo "<p>Mobile Number: " . $userDetails['phno'] . "</p>";

                // Display update form
                echo "<form method='POST' action=''>
                        <input type='text' name='name' value='" . $userDetails['name'] . "' placeholder='Name'><br>
                        <input type='text' name='address' value='" . $userDetails['address'] . "' placeholder='Address'><br>
                        <input type='text' name='phno' value='" . $userDetails['phno'] . "' placeholder='Mobile Number'><br>
                        <input type='submit' name='update' value='Update'>
                      </form>";

                // Process form submission
                if (isset($_POST['update'])) {
                    $name = $_POST['name'];
                    $address = $_POST['address'];
                    $phno = $_POST['phno'];

                    // Update user details
                    if (updateUserDetails($conn, $userId, $name, $address, $phno)) {
                        echo "<p class='success-message'>User details updated successfully.</p>";
                        echo "<p class='success-message'>Refresh the page to see the updated details, or u can directly go to home page.</p>";
                    } else {
                        echo "<p class='error-message'>Failed to update user details.</p>";
                    }
                }
            } else {
                echo "<p class='error-message'>User not found.</p>";
            }

            // Close the database connection
            $conn->close();
        ?>
        <div class="d-grid gap-2 col-6 mx-auto">
            <a class="btn btn-primary" href="vamsi.php">Go To Home</a>
        </div>
    </div>
</body>
</html>
