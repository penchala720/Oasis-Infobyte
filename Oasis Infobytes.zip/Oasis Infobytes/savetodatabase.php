<?php

// include connection to database
include("database.php");

//retriving the cookie to here -created in loginprocess.php
$youremail = $_COOKIE['varus_name']; 
//setting default time zone as india
date_default_timezone_set('Asia/Kolkata');

//at intial stage setting order status as 
$orderstatus="ordered";

//invoice seting as click to download
$bill="click to download";

//collecting the data of the user
$ddata = "SELECT * FROM userdetail WHERE email = '$youremail'";
$result = $conn->query($ddata);
$rowe = $result->fetch_assoc();
$cusname = $rowe['name'];
$cuscontact = $rowe['phno'];
$cusaddress = $rowe['address'];

//creating a variable for storing date
$myDate = date ('Y/m/d');
$myTime = date('H:i:s');
$datetime = $myDate . " " . $myTime;

// Retrieve the cart data from the POST request
$cartData = $_POST['cartData'];

// Convert the JSON string back to a PHP array
$cart = json_decode($cartData, true);



// Insert each item from the cart into the 'fooddetails' table
foreach ($cart as $item) {
    $foodName = $item['name'];
    $foodprice = $item['price'];
    $sql = "INSERT INTO orders (usere, itemname, itemprice, date, orderstatus, invoice, customername, customercontact, customeraddress)
    VALUES ('$youremail', '$foodName', '$foodprice', '$datetime', '$orderstatus', '$bill','$cusname', '$cuscontact','$cusaddress')";
    if ($conn->query($sql) === false) {
        echo "Error: " . $sql . "<br>" . $conn->error();
    }
}

echo "<script>location.href = 'vamsi.php';</script>";

$conn->close();
?>