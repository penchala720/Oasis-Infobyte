<!DOCTYPE html>
<html>
<head>
    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">

    <style>
        /* Custom styles */
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #ff4c68;
            color: #333;
        }

        .container {
            margin-top: 20px;
            background-color: #fff;
            border-radius: 5px;
            padding: 20px;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0069d9;
            border-color: #0062cc;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f8f9fa;
            color: #333;
            font-weight: bold;
        }

        tbody tr:hover {
            background-color: #f1f1f1;
        }
    </style>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">

</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-12">
            <button type="button" class="btn btn-primary">
                <a href="vamsi.php" style="color:white; text-decoration:none;">Go To Home</a>
            </button>
        </div>
    </div>

    <?php
    // making database connection
    // include connection to database
    include("database.php");

    //retrieving the cookie to here -created in loginprocess.php
    $userID = $_COOKIE['varus_name'];

    // Get the user ID from the query string or form submission
    // $userID = $_GET['userID']; // Assuming you're using the GET method, adjust accordingly if using POST

    // Prepare the SQL query to retrieve data for the specified user ID, sorted by date
    $query = "SELECT * FROM orders WHERE usere = '$userID' ORDER BY date DESC";

    // Execute the query
    $result = mysqli_query($conn, $query);

    // Check if any rows were returned
    if (mysqli_num_rows($result) > 0) {
        // Output table headers
        echo '<div class="row">
                    <div class="col-12">
                        <table class="table table-striped" style="background-color: #fff;">
                            <thead>
                                <tr>
                                    <th scope="col">Item Name</th>
                                    <th scope="col">Item Price</th>
                                    <th scope="col">Date</th>
                                    <th scope="col">Order Status</th>
                                    <th scope="col">Invoice</th>
                                </tr>
                            </thead>
                            <tbody>';

        // Output data rows
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>".$row['itemname']."</td>";
            echo "<td>".$row['itemprice']."</td>";
            echo "<td>".$row['date']."</td>";
            echo "<td>".$row['orderstatus']."</td>";
            echo "<td>".$row['invoice']."</td>";
            echo "</tr>";
        }

        echo '</tbody>
              </table>
          </div>
      </div>';
    } else {
        echo '<div class="row">
                <div class="col-12">
                    <p>No data found for the specified user ID.</p>
                </div>
            </div>';
    }

    // Close the database connection
    mysqli_close($conn);
    ?>
</div>

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
</body>
</html>
