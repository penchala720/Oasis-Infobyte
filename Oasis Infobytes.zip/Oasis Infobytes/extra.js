var cart = [];
function addToCart(itemName, itemPrice) {
	var item = {
		name: itemName,
		price: itemPrice
	};

	cart.push(item);

	updateCart();
}
function removeFromCart(index) {
	cart.splice(index, 1);

	updateCart();
}

function updateCart() {
	var cartElement = document.getElementById("cart");

	if (cart.length === 0) {
		cartElement.innerHTML = "<p>Your cart is empty.</p>";
	} else {
		var table = "<table><tr><th>Name</th><th>Price</th><th></th></tr>";
		var total = 0;
		for (var i = 0; i < cart.length; i++) {
			table += "<tr><td>" + cart[i].name + "</td><td>₹" + cart[i].price.toFixed(2) + "</td><td><button onclick=\"removeFromCart(" + i + ")\">Remove</button></td></tr>";
			total += cart[i].price;
		}
		table += "<tr><td>Total:</td><td>₹" + total.toFixed(2) + "</td><td></td></tr>";
		table += "</table>";

		cartElement.innerHTML = table;
	}
}

function orderp()
{
	alert("Your Order has been placed successfully");  
	  // Convert the 'cart' array to a JSON string
	  var cartData = JSON.stringify(cart);
	  
	  // Create a form dynamically
	  var form = document.createElement('form');
	  form.method = 'post';
	  form.action = 'savetodatabase.php'; // PHP file to handle the data
	  
	  // Create an input field and add the JSON string as its value
	  var input = document.createElement('input');
	  input.type = 'hidden';
	  input.name = 'cartData';
	  input.value = cartData;
	  
	  // Append the input field to the form
	  form.appendChild(input);
	  
	  // Submit the form
	  document.body.appendChild(form);
	  form.submit();
	  
}