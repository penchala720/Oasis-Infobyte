<?php
//database
include("database.php");

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

  // Collect the email address from the form
  $email = $_POST['email'];

  // Validate the email address
  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $error = 'Invalid email address';
  } else {

    // Check if the email address exists in the database
    $query = "SELECT * FROM userdetail WHERE email = '$email'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 0) {
      $error = 'Email address not found';
    } else {

      // Generate a unique token for the password reset link
      $token = bin2hex(random_bytes(32));

      // Store the token in the database along with the user's email address
      $query = "INSERT INTO password_resets (email, token) VALUES ('$email', '$token')";
      mysqli_query($conn, $query);

      // Send the password reset link to the user's email address
      $reset_link = "localhost/reset-password.php?token=$token";
      $subject = 'Reset Your Password';
      $message = "To reset your password, click this link: $reset_link";
      mail($email, $subject, $message);

      // Display a success message
      $success = 'An email has been sent with instructions for resetting your password';
    }
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Forgot Password</title>
</head>
<body>
  <?php if (isset($error)): ?>
    <p>Error: <?php echo $error ?></p>
  <?php endif ?>

  <?php if (isset($success)): ?>
    <p><?php echo $success ?></p>
  <?php else: ?>
    <form method="post">
      <label>Email address:</label>
      <input type="email" name="email" required>
      <button type="submit">Reset Password</button>
    </form>
  <?php endif ?>
</body>
</html>
