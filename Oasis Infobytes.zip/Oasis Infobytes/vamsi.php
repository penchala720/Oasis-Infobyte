<?php
//retriving the cookie to here -created in loginprocess.php
$your_variable = $_COOKIE['varus_name']; 
?>
<!-- the web page main code starts from here -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/7dd8c8bf53.js" crossorigin="anonymous"></script>
    <!-- bootstrap-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
    <!--javascript-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js" integrity="sha384-qKXV1j0HvMUeCBQ+QVp7JcfGl760yU08IQ+GpUo5hlbpg51QRiuqHAJz8+BrxE/N" crossorigin="anonymous"></script>
    <!--external css-->
    <link rel="stylesheet" href="styles.css">
    <!--foont's google-->
    <link href="https://fonts.googleapis.com/css2?family=Foldit&family=Saira+Semi+Condensed&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display&display=swap" rel="stylesheet">
    <title>Pizza's</title>
</head>
<body>
    <nav class="navbar sticky-top bg-light navbar-expand-lg navbar-light" style="padding:0 8px;">
        <a class="navbar-brand" href="">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
        <span >CATEGORIES</span>
       </button>
       <div class="collapse navbar-collapse " id="navbarTogglerDemo01">
        <ul class="navbar-nav ms-auto">
            <li class="nav-item">
                <a class="nav-link navbutton" href="profile.php">Profile</a>
            </li>
            <li class="nav-item">
                <a class="nav-link navbutton" href="collectingorders.php">MyOrders</a>
            </li>
            <li class="nav-item">
                <a class="nav-link navbutton" href="#food">Specials</a>
            </li>
            <li class="nav-item">
                <a class="nav-link navbutton" href="#biry">Dessert</a>
            </li>
            <li class="nav-item">
                <a class="nav-link navbutton" href="#chick">Greek</a>
            </li>
            <li class="nav-item">
                <a class="nav-link navbutton" href="#VEG">Hawaiian</a>
            </li>
            <li class="nav-item">
                <a class="nav-link navbutton" href="#TIFFINS">Detroit</a>
            </li>
            <li class="nav-item">
                <a class="nav-link navbutton" href="index.php">LOGOUT</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#cart"><i class="fa-solid fa-cart-shopping" style="color: #ff3028;"></i></a>
            </li>
        </ul>
        </div>
    </nav>
    <div class="one">
        <div class=" oneone">
            <div class="oneoneone">
                <img class="welcimg" src="welcome.png" alt="welcome image">     
            </div>
            <div class="oneonetwo" style="padding:2% 8% 8% 8%;">
                <h2 style="font-family: 'Playfair Display', serif; font-size: 6vw; color: red; ">
                    Food That Makes You To Say WOW!<br>
                    <i class="fa-solid fa-utensils" style="color: #ff0028;"></i>
                </h2>
            </div>
        </div>
    </div>
    <div class="menu">
        <div class="row" id="biry">
            <h3>Hot Dessert's</h3>
            <div class="col col-lg-4 col-md-6">
                <div class="card border-warning" style="width: 16rem;">
                    <img src="pizza 2.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                      <h5 class="card-title">Mozzo</h5>
                      <p class="card-text">₹100</p>
                      <button class="btn btn-warning" onclick="addToCart('Mozzo', 80)">Add to Cart</button>
                    </div>
                </div>
            </div>
            <div class="col col-lg-4 col-md-6 ">
                <div class="card border-warning" style="width: 16rem;">
                    <img src="Mutbir.jpeg" class="card-img-top" alt="...">
                    <div class="card-body">
                      <h5 class="card-title">Lappetto</h5>
                      <p class="card-text">₹220</p>
                      <button class="btn btn-warning" onclick="addToCart('Lappetto', 220)">Add to Cart</button>
                    </div>
                </div>   
            </div>
            <div class="col col-lg-4 col-md-6 ">
                <div class="card border-warning" style="width: 16rem;">
                    <img src="ChicBir.jpeg" class="card-img-top" alt="...">
                    <div class="card-body">
                      <h5 class="card-title">Stefano's</h5>
                      <p class="card-text">₹160</p>
                      <button class="btn btn-warning" onclick="addToCart('Stefano', 160)">Add to Cart</button>
                    </div>
                </div> 
            </div>
        </div>
        <div class="row" id="chick">
        <h3>Greek Special's</h3>
        <div class="col col-lg-4 col-md-6">
            <div class="card border-warning" style="width: 16rem;">
                <img src="butterchicken.jpeg" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">Posto Guizzo</h5>
                  <p class="card-text">₹140</p>
                  <button class="btn btn-warning" onclick="addToCart('Posto Guizzo', 140)">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="col col-lg-4 col-md-6 ">
            <div class="card border-warning" style="width: 16rem;">
                <img src="ChickenCurry.jpeg" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">Cruzer Pizza</h5>
                  <p class="card-text">₹110</p>
                  <button class="btn btn-warning" onclick="addToCart('Cruzer Pizza', 110)">Add to Cart</button>
                </div>
            </div>   
        </div>
        <div class="col col-lg-4 col-md-6 ">
            <div class="card border-warning" style="width: 16rem;">
                <img src="chickenrost.jpeg" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">Muyana Pie</h5>
                  <p class="card-text">₹150</p>
                  <button class="btn btn-warning" onclick="addToCart('Muyana Pie', 150)">Add to Cart</button>
                </div>
            </div> 
        </div>
      </div>
     <div class="row" id="VEG">
        <h3>Hawaiian</h3>
        <div class="col col-lg-4 col-md-6">
            <div class="card border-warning" style="width: 16rem;">
                <img src="vegetable-biryani.jpeg" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">First Taste</h5>
                  <p class="card-text">₹80</p>
                  <button class="btn btn-warning" onclick="addToCart('First Taste', 80)">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="col col-lg-4 col-md-6 ">
            <div class="card border-warning" style="width: 16rem;">
                <img src="veg-fried-rice.jpeg" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">First Slice</h5>
                  <p class="card-text">₹100</p>
                  <button class="btn btn-warning" onclick="addToCart('First Slice', 100)">Add to Cart</button>
                </div>
            </div>   
        </div>
        <div class="col col-lg-4 col-md-6 ">
            <div class="card border-warning" style="width: 16rem;">
                <img src="Paneer-Butter-Masala.jpeg" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">Pizzawings</h5>
                  <p class="card-text">₹160</p>
                  <button class="btn btn-warning" onclick="addToCart('Pizza wings', 160)">Add to Cart</button>
                </div>
            </div> 
        </div>
    </div>
    <div class="row" id="TIFFINS">
        <h3>Detroit's</h3>
        <div class="col col-lg-4 col-md-6">
            <div class="card border-warning" style="width: 16rem;">
                <img src="plain-dosa.jpeg" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">Basil City Pizza</h5>
                  <p class="card-text">₹50</p>
                  <button class="btn btn-warning" onclick="addToCart('Basil City Pizza', 50)">Add to Cart</button>
                </div>
            </div>
        </div>
        <div class="col col-lg-4 col-md-6 ">
            <div class="card border-warning" style="width: 16rem;">
                <img src="onion-uttapam.jpeg" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">Sreebon</h5>
                  <p class="card-text">₹60</p>
                  <button class="btn btn-warning" onclick="addToCart('Sreebon', 60)">Add to Cart</button>
                </div>
            </div>   
        </div>
        <div class="col col-lg-4 col-md-6 ">
            <div class="card border-warning" style="width: 16rem;">
                <img src="sambhar-vada.jpeg" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">Napolli</h5>
                  <p class="card-text">₹60</p>
                  <button class="btn btn-warning" onclick="addToCart('Napolli', 60)">Add to Cart</button>
                </div>
            </div> 
        </div>
    </div>
</div>
<div id="food" style="text-align:center;">
<div class="container">
            <h2 class="text-center">Special for Special's</h2>
            <?php include('configgg/constants.php'); ?>
            <?php 
                //Display Foods that are Active
                $sql = "SELECT * FROM tbl_food WHERE active='Yes'";

                //Execute the Query
                $res=mysqli_query($conn, $sql);

                //Count Rows
                $count = mysqli_num_rows($res);

                //CHeck whether the foods are availalable or not
                if($count>0)
                {
                    //Foods Available
                    while($row=mysqli_fetch_assoc($res))
                    {
                        //Get the Values
                        $id = $row['id'];
                        $title = $row['title'];
                        $description = $row['description'];
                        $price = $row['price'];
                        $image_name = $row['image_name'];
                        ?>
                        
                        <div style="display:inline-block;">
                        <div class="col col-lg-4 col-md-6">
                          <div class="card border-warning" style="width: 16rem; margin:10px 50px;">
                            <div>
                                <?php 
                                    //CHeck whether image available or not
                                    if($image_name=="")
                                    {
                                        //Image not Available
                                        echo "<div class='error'>Image not Available.</div>";
                                    }
                                    else
                                    {
                                        //Image Available
                                        ?>
                                        <img src="images/food/<?php echo $image_name; ?>" alt="Chicke Hawain Pizza" class="card-img-top" style="width:16rem; height:12rem;">
                                        <?php
                                    }
                                ?>
                                
                            </div>

                            <div class="card-body">
                                <h4><?php echo $title; ?></h4>
                                <p class="food-price">₹<?php echo $price; ?></p>
                                <p class="food-detail">
                                    <?php echo $description; ?>
                                </p>
                                <br>

                                <button class="btn btn-warning" onclick="addToCart('<?php echo $title; ?>', <?php echo $price; ?>)">Add to Cart</button>
                            </div>
                          </div>
                        </div>
                        </div>

                        <?php
                    }
                }
                else
                {
                    //Food not Available
                    echo "<div class='error'>Food not found.</div>";
                }
            ?>
        </div>
</div>
    <div class="billpart">
        <h1>Cart<span id="variableValue"></span></h1>
	    <div id="cart">
		    <p>Your cart is empty.</p>
        </div>
        <div class="d-grid gap-2 col-6 mx-auto">
        <button class="btn btn-primary" onclick="orderp()">PlaceOrder</button>
        <div id="message"></div>
        </div>
    </div>
    <div style="padding:2% 8%;">
    <footer>
    <div class="footer-content">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h3>About Us</h3>
                    <p>Our mission is to provide delicious and nutritious food to the people.</p>
                </div>
                <div class="col-md-4">
                    <h3>Contact Us</h3>
                    <p>Email: m.vamsi3924@gmail.com</p>
                    <p>Phone: 8309646666</p>
                    <p>Address:  Thandalam, Chennai, INDIA</p>
                </div>
                <div class="col-md-4">
                    <h3>Follow Us</h3>
                    <ul class="social-icons">
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="https://twitter.com/"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <p>&copy; <?php echo date("Y"); ?> Developed By <a href="https://github.com/penchala720/">Vundela Penchala Reddy</a></p>
                </div>
            </div>
        </div>
    </div>
</footer>

    </div>
    <script src="extra.js"></script>  
    
</body>
</html>