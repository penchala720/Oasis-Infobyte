<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pizza's</title>
    <link rel="stylesheet" href="logi.css">
</head>
<body>
    <div class="box">
        <span class="borderline"></span>
        <form action="loginprocess.php" id="log-form" method="post">
            <div class="buttons-container">
                <button id="log-btn" class="active"></button>
            </div>
        <h2>Sign in</h2>
        <div class="inputbox">
            <input type="text" name="usema" id="" required="required" style="padding-left: 5px;">
            <span>Usermail</span>
            <i></i>
        </div>
        <div class="inputbox">
            <input type="password" name="passw" id="" required="required" style="padding-left: 5px;">
            <span>Password </span>
            <i></i>
        </div>
        <div class="links">
            <a href="forgotpassword.php">Forgot Password</a>
            <a href="#" id="reg-btn">SignUp</a>
        </div>
        <div class="links">
            <a href="admin/login.php">Admin</a>
        </div>
        <input type="submit" value="Login">
        <button style="float: right;" ><a href="vamsi.php" style=" text-decoration: none; ">  SKIP, LOGIN ➡️</a></button>

        </form>
        <form action="registerprocess.php" id="reg-form" method="POST">
            <h2>Sign Up</h2>
            <div class="inputbox2">
                <span>Username</span><br>
                <input type="text" name="usename" id="usname" required="required" style="padding-left: 5px;">
                <i></i>
            </div>
            <div class="inputbox2">
                <span>Email</span><br>
                <input type="email" name="uemail" id="gmail" required="required" style="padding-left: 5px;">
                <i></i>
            </div>
            <div class="inputbox2">
                <span>Mobile Number</span><br>
                <input type="text" name="umbn" id="phno" required="required" style="padding-left: 5px;">
                <br>
                <i></i>
            </div>
            <div class="inputbox2">
                <span>Address</span><br>
                <input type="textbox" name="uadres" id="adpas" required="required" style="padding-left: 5px;">
                <i></i>
            </div>
            <div class="inputbox2">
                <span>New Password </span><br>
                <input type="password" name="ucpas" id="cpass" required="required" style="padding-left: 5px;">
                <br>
                <i></i>
            </div>
            <a style="color: white; text-decoration: none;" href="index.php">LOGIN </a>
        <button type="submit" style="font-size:15px;
            margin: 5px 0;
            font-family:Arial;
            width:100px;
            height:30px;
            border-width:1px;
            color:rgba(231, 18, 18, 1);
            border-color:#dcdcdc;
            font-weight:bold;
            border-radius:6px;
            box-shadow:inset 0px 1px 0px 0px #ffffff;
            background:linear-gradient(#f9f9f9, #e9e9e9);">Submit</button>
        </form>
    </div>
    <script src="loginp.js"></script>
</body>
</html>