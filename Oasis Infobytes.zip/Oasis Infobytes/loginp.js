const loginForm = document.getElementById("log-form");
const registerForm = document.getElementById("reg-form");
const loginBtn = document.getElementById("log-btn");
const registerBtn = document.getElementById("reg-btn");

loginBtn.addEventListener("click", () => {
    loginForm.style.display = "block";
    registerForm.style.display = "none";
});

registerBtn.addEventListener("click", () => {
    loginForm.style.display = "none";
    registerForm.style.display = "block";
});

// Default to login form
loginForm.style.display = "block";
registerForm.style.display = "none";